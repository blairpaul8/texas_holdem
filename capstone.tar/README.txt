Camden Goering, Paul Blair, Nick Rich - Capstone Lab 3-Card Poker

- There is a makefile included use make and then ./main to run the game.

- This lab works like standard poker, just with 3 cards.
You (the player) start with $10-$50 when starting a new game, you are then prompted for a blind bet.

- Cards are then dealt and you can chose to bet again or check (no bet).
When making a bet the money is subtracted from the player and added to the pot, any money added to the pot is doubled by the dealer.

- The players cards are then compared to the dealers to see who won (win -> you get pot money, lose -> dealer gets pot money).

- You are then prompted if you want to play again or not, if so you keep all money and play again, if you run out of money the game automatically ends.

- scoring card hands (highest to lowest, highest wins): straight flush, three of a kind, straight, flush, pair, high card
